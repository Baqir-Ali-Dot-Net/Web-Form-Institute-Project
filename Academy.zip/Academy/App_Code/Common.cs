﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Common
/// </summary>
public class Common
{

    public static string empId;
    public static string adminId;
    public static string adminName;
    public static string week;
    public static string month;
    public static int year;
    public static DateTime date;
    public static bool command;
    public static int clientId;
    public static int Id;
}